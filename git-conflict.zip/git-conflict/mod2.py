# This is a sample file
a = 5
b = 6
f = "x"
