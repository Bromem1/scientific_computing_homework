import sys
import os
import scipy
from scipy.stats import binom, gamma
import scipy.linalg
import numpy
import mod2

print("This is some code")
